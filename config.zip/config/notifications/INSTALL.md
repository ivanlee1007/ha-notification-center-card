# Notification Framework — Installation

## Prerequisites

- Home Assistant with `!include_dir_named packages/` in `configuration.yaml`
- HACS integration: [`Variable (var)`](https://github.com/snarky-snark/home-assistant-variables) — for snooze and repeat maps without the 255-char limit
- Custom card: [`custom:button-card`](https://github.com/custom-cards/button-card) (HACS)
- Custom card: [`custom:card-mod`](https://github.com/thomasloven/lovelace-card-mod) (HACS) — required for the critical banner only
- Optional: `notify.gmail_smtp` for email delivery

---

## Step 1 — Copy files

Target structure in your HA configuration:

```
config/
├── configuration.yaml
├── packages/
│   └── notifications.yaml                ← framework entry point
├── notifications/
│   ├── templates/
│   │   ├── notif_sources.yaml            ← ✏️ primary edit point
│   │   └── notif_aggregation.yaml        ← do not edit
│   └── notif_automations.yaml            ← do not edit (except service names)
└── lovelace/
    └── notifications/
        ├── notif_shared.yaml             ← Shared base template
        ├── notif_chip_2.yaml             ← Chip + floating dropdown
        ├── notif_banner.yaml             ← Critical Banner
        ├── notif_pills.yaml              ← Pill strip
        └── notif_list.yaml               ← List Card Template
```

---

## Step 2 — Verify packages support

`configuration.yaml` must contain:

```yaml
homeassistant:
  packages: !include_dir_named packages/
```

That is all — `notifications.yaml` is loaded automatically,
no further entry needed.

---

## Step 2b — Install the Variable integration (HACS)

The framework uses the [Variable (var)](https://github.com/snarky-snark/home-assistant-variables)
integration from HACS for the snooze and repeat maps. `input_text` is capped at 255 characters
which is insufficient for multiple simultaneous notifications.

**Installation:**
1. HACS → Integrations → search for `Variable` → Install
2. Restart HA
3. Add to `configuration.yaml`:

```yaml
var:
```

> **Note:** The `var:` entities themselves are defined in `packages/notifications.yaml` —
> you only need to add the empty `var:` key to `configuration.yaml` so the integration loads.

---

## Step 3 — Configure notify services

Open `notifications/notif_automations.yaml` and replace the two placeholder service names:

| Service name | Role | Occurrences |
|---|---|---|
| `notify.notify` | Mobile push | 3 |
| `notify.gmail_smtp` | Email | 2 |

Use Find in your editor to jump to each location.

If you do not use email, comment out all `notify.gmail_smtp` blocks
(add `#` before each line in the two email delivery sections).

---

## Step 4 — Review user config helpers

`packages/notifications.yaml` is split into two clearly marked sections:

- **FRAMEWORK INTERNALS** (marked `██`) — do not edit
- **USER SETTINGS** (marked `▓▓`) — safe to adjust

The User Settings section contains:

| Entity | Purpose | Default |
|---|---|---|
| `input_number.notification_critical_repeat_interval_min` | How often critical alerts repeat | 10 min |
| `input_number.notification_battery_threshold_pct` | Low battery alert threshold | 20 % |
| `input_number.notification_filter_interval_days` | Kitchen filter replacement interval | 120 days |
| `input_number.car_current_mileage` | Current car mileage | — |
| `input_number.car_next_service_km` | Mileage at next service | — |
| `input_datetime.kitchen_filters_replaced` | Date filters were last replaced | — |

Remove any entries you do not need (and comment out the corresponding source
in `notif_sources.yaml`).

---

## Step 5 — Restart HA

Reload via **Developer Tools → YAML → All YAML configuration**,
or fully restart HA.

Then verify under **Developer Tools → States**:

| Entity | Expected state |
|---|---|
| `sensor.notification_feed` | `0` |
| `sensor.notification_count_critical` | `0` |
| `binary_sensor.notification_any_active` | `off` |
| `binary_sensor.notification_any_critical` | `off` |
| `var.notification_snooze_map` | `{}` |
| `var.notification_repeat_map` | `{}` |

---

## Step 6 — Include UI components

### Chip + Dropdown

```yaml
- !include ../../lovelace/notifications/notif_chip_2.yaml
```

### Critical Banner (floating)

```yaml
- !include ../../lovelace/notifications/notif_banner.yaml
```

### List Card Template

Add the contents of `notif_list.yaml` to your `button_card_templates`
configuration, then use as:

```yaml
type: custom:button-card
entity: sensor.notification_feed
template: notif_list
view_layout:
  grid-area: your-area
```

---

## Adding a new notification

1. Open `notifications/templates/notif_sources.yaml`
2. Copy the template block at the bottom of **Section A**
3. Adjust `name`, `state`, `priority`, `text_summary`, `text_description`
4. Restart HA

New notifications are auto-discovered by `sensor.notification_feed` —
no further action needed.

Section C at the bottom of `notif_sources.yaml` contains ready-to-use
commented example blocks for common use cases.

---

## Localising UI labels

`notif_chip_2.yaml` and `notif_list.yaml` inherit their shared labels and basic
display defaults from `notif_shared.yaml`. Variant-specific labels stay in the
individual template files.

The shared labels are exposed in the `variables:` block, for example:

```yaml
variables:
  label_snooze: "Snooze"
  label_confirm: "Done"
  label_h1: "1h"
  label_h4: "4h"
  label_tomorrow: "Tomorrow"
  label_day_after: "Day after"
```

Edit the shared `label_*` values in `notif_shared.yaml` for chip + list together.
Edit `notif_pills.yaml` or `notif_banner.yaml` separately for component-specific labels.

---

## Troubleshooting

**`sensor.notification_feed` stays `unknown`**
→ Verify that `!include_dir_named packages/` is active in `configuration.yaml`
  and that the directory structure matches exactly.

**Spurious trigger on HA restart**
→ The startup guard filters `unknown`/`unavailable → on` transitions.
  If it still fires, check that the affected source correctly evaluates
  to `false` when the sensor is unavailable.

**Snooze not working**
→ Check `var.notification_snooze_map` under Developer Tools → States.
  Must contain valid JSON (`{}`). No character limit with the var integration.

**Email not sent**
→ Check the service name in `notif_automations.yaml` (Step 3).
  Test the service directly under Developer Tools → Services.
