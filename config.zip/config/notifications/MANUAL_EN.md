# Notification Framework for Home Assistant — Manual

---

## Concept

The framework provides a unified, extensible notification system for Home Assistant.
It abstracts push notifications, emails, persistent notifications, and dashboard
display behind a single simple interface:

**One new alert = One new `binary_sensor.notification_*` with attributes.**

The system automatically handles:
- Routing by priority (Mobile Push, Email, Persistent Notification)
- Repetition of critical alerts at a configurable interval
- Per-alert snooze directly from the dashboard
- Confirmation actions per alert (e.g. "Filter replaced")
- Dashboard display as chip + dropdown, floating banner, or scrollable list

---

## Architecture

```
binary_sensor.notification_*   ←  Sources (custom logic, freely extensible)
         │
         ▼
sensor.notification_feed        ←  collects all active, non-snoozed sources
         │
         ├──▶  notif_chip_2.yaml        →  Dashboard chip + floating dropdown
         ├──▶  notif_banner.yaml        →  floating critical banner
         ├──▶  notif_list               →  full notification list (template)
         │
         └──▶  notif_automations.yaml
                    ├── Router           →  detects on/off, checks snooze & startup
                    ├── Delivery Mobile  →  notify.notify
                    ├── Delivery Email   →  notify.gmail_smtp
                    ├── Delivery Persist →  persistent_notification
                    ├── Critical Repeat  →  repeats every N minutes
                    ├── Snooze Set       →  updates snooze map
                    ├── Cleanup Maps     →  daily cleanup of stale entries
                    └── Snooze Catch-up  →  re-delivers on snooze expiry
```

---

## File Structure

```
config/
├── packages/
│   └── notifications.yaml                  ← Helpers & entry point
│
├── notifications/
│   ├── templates/
│   │   ├── notif_sources.yaml              ← ✏️ primary edit point
│   │   └── notif_aggregation.yaml          ← do not edit
│   └── notif_automations.yaml              ← do not edit (except service names)
│
└── lovelace/notifications/
    ├── notif_shared.yaml                   ← Shared base template
    ├── notif_chip_2.yaml                   ← Chip + floating dropdown
    ├── notif_banner.yaml                   ← Floating critical banner
    ├── notif_pills.yaml                    ← Pill strip
    └── notif_list.yaml                     ← List card template
```

### `notifications.yaml` structure

The package file is divided into two clearly marked sections:

- **FRAMEWORK INTERNALS** (`██` header) — `var.*` maps and `input_boolean`. Do not edit.
- **USER SETTINGS** (`▓▓` header) — thresholds and source-specific helpers. Safe to adjust.

User Settings sub-sections:
- *Framework thresholds* — repeat interval, battery threshold
- *Source-specific values* — helpers tied to specific notification sources (filter interval, car mileage)
- *Date helpers* — `input_datetime` entries

---

## Adding a New Alert

Add a new block in `notif_sources.yaml` under Section A:

```yaml
- name: notification_<slug>
  unique_id: notification_<slug>
  state: >
    {{ is_state('binary_sensor.my_entity', 'on') }}
  attributes:
    priority: warning
    category: general
    icon: mdi:alert
    icon_color: "var(--warning-color)"
    text_summary: "Short title"
    text_description: "Optional detail text"
    tap_action: more-info
    tap_action_entity: binary_sensor.my_entity
```

After restarting HA the alert is automatically detected by the feed sensor —
no further configuration needed.

Section C at the bottom of `notif_sources.yaml` contains ready-to-use commented
example blocks for common use cases (CO2, ventilation filters, vacuum, water leak,
vacation mode, electricity price).

---

## Attributes

### Required

| Attribute | Type | Description |
|-----------|------|-------------|
| `priority` | `critical` \| `warning` \| `info` | Controls routing and display |
| `text_summary` | string | Short title — shown in dropdown and push notifications |

### Optional

| Attribute | Type | Description |
|-----------|------|-------------|
| `category` | string | Free categorization (e.g. `maintenance`, `security`) |
| `icon` | `mdi:*` | Icon in the dropdown |
| `icon_color` | CSS variable or hex | Icon color |
| `text_description` | string | Detail text in dropdown and email |
| `tap_action` | `more-info` \| `dialog` \| `navigate` \| `url` | Action on row click |
| `tap_action_entity` | entity_id | For `more-info` and `dialog` |
| `tap_action_navigation_path` | `/lovelace/…` | For `navigate` |
| `tap_action_url_path` | `https://…` | For `url` |
| `confirm_action` | `domain.service` | Service call triggered by the confirm button |
| `confirm_label` | string | Confirm button label (default: "Done") |
| `confirm_service_data` | JSON string | Service data as JSON string. `"TODAY"` is replaced at runtime with the current date in `YYYY-MM-DD` format |

### Important Rules

- `state` must explicitly return `false` when the dependent entity is `unavailable` or `unknown`.
- Always use safe defaults: `| int(0)`, `| float(0.0)`.
- `state_attr(...)` can return `None` — check before using `| list`.
- For numeric sensor values always validate: `not in ['unknown','unavailable','']` **and** `| int(-1) >= 0` — prevents phantom values during startup.
- The snooze slug is derived from the entity name: `binary_sensor.notification_front_door_open` → slug `front_door_open`.

---

## Priority Routing

| Priority | Mobile Push | Persistent | Email | Critical Repeat |
|----------|:-----------:|:----------:|:-----:|:---------------:|
| critical | ✅ | ✅ | ✅ | ✅ |
| warning  | ✅ | ❌ | ✅ | ❌ |
| info     | ❌ | ✅ | ❌ | ❌ |

- **Mobile:** `notify.notify` (replace with your service)
- **Email:** `notify.gmail_smtp` (replace with your service)
- **Critical Repeat:** interval configurable via `input_number.notification_critical_repeat_interval_min` (default: 10 min)

---

## Router — Conditions

The router only fires when all four conditions are met:

1. Entity matches `binary_sensor.notification_*` (aggregation sensors excluded)
2. Transition was `off → on`
3. Previous state was **not** `unknown` / `unavailable` / empty — prevents spurious alerts on HA restart
4. Notification is not currently snoozed

---

## Dashboard — Three Independent UI Components

### Chip + Dropdown (`notif_chip_2.yaml`)

Always visible in the assigned grid area.

| State | Icon | Badge |
|-------|------|-------|
| No active alerts | `mdi:bell-outline` | — |
| Active alerts | `mdi:bell-badge` | Count |
| Dropdown open | `mdi:bell-ring` | Count |

Click opens the dropdown with all active alerts sorted by priority. Each row has
a priority color bar, icon, summary, optional description, snooze button (warning/info)
or confirm button (when `confirm_action` is set).

### Critical Banner (`notif_banner.yaml`)

Floats `position: fixed` above the dashboard via `card-mod` (`top: 60px`, centered).
Only renders when critical alerts are active. Clicking a row executes its `tap_action`.

### List Card (`notif_list.yaml`)

Button-card template. Scrollable list of all active alerts with priority color bars,
snooze panel, and confirm button.

```yaml
type: custom:button-card
entity: sensor.notification_feed
template: notif_list
view_layout:
  grid-area: boxX
```

### Localising UI labels

`notif_chip_2.yaml` and `notif_list.yaml` inherit shared labels and base defaults
from `notif_shared.yaml`. Variant-specific labels remain in the individual template files.

The shared labels live in the `variables:` block, for example:

```yaml
variables:
  label_snooze: "Snooze"
  label_confirm: "Done"
  label_h1: "1h"
  label_h4: "4h"
  label_tomorrow: "Tomorrow"
  label_day_after: "Day after"
```

Edit the shared `label_*` values in `notif_shared.yaml` to localise chip + list together.
Localise `notif_pills.yaml` and `notif_banner.yaml` separately.

---

## Snooze

Click the snooze button in the dropdown or list card to expand the time picker:

| Option | Time |
|--------|------|
| 1h | Now + 1 hour |
| 4h | Now + 4 hours |
| Tomorrow | Next day at 08:00 |
| Day after | Day after tomorrow at 08:00 |

Timestamps are stored in **local time** (not UTC). Alternatively fire the event manually:

```yaml
event: notification_snooze
event_data:
  slug: front_door_open
  until: "2026-03-10T08:00:00"
```

Snoozed alerts are excluded from badge, dropdown, banner, list card, and push/email delivery.

**Snooze catch-up:** If an alert becomes active during a snooze period, the
`notification_snooze_catchup` automation re-delivers it as soon as the snooze expires
(checked every minute). This ensures no notification is silently missed.

---

## Confirmation Action

```yaml
confirm_action: input_datetime.set_datetime
confirm_label: "Filter replaced"
confirm_service_data: '{"entity_id":"input_datetime.kitchen_filters_replaced","date":"TODAY"}'
```

`TODAY` is replaced at runtime with the current date in `YYYY-MM-DD` format.

Button logic by priority:

| Condition | Snooze button | Confirm button |
|---|---|---|
| `critical` + no `confirm_action` | — | — |
| `critical` + `confirm_action` | — | ✅ |
| `warning`/`info` + no `confirm_action` | ✅ | — |
| `warning`/`info` + `confirm_action` | — | ✅ |

---

## JSON Storage

The framework stores two JSON maps in `var` entities — persisted in HA's SQLite
database and survive restarts.

### `var.notification_snooze_map`
```json
{"water_leak": "2026-03-10T08:00:00", "low_battery": "2026-03-11T08:00:00"}
```
Written by `notification_snooze_set`. Read by feed sensor and router.

### `var.notification_repeat_map`
```json
{"smoke_co_alarm": "2026-03-09T16:42:00"}
```
Written by the critical repeat automation after each send.
Orphaned entries are removed daily by `notification_cleanup_maps`.

---

## Helpers

### Framework internals — do not edit

| Entity | Purpose | Default |
|---|---|---|
| `var.notification_snooze_map` | JSON map: slug → snooze timestamp | `{}` |
| `var.notification_repeat_map` | JSON map: slug → last repeat timestamp | `{}` |
| `input_boolean.notification_dropdown_open` | Controls dropdown open/close state | `false` |

### User settings — safe to adjust

| Entity | Purpose | Default |
|---|---|---|
| `input_number.notification_critical_repeat_interval_min` | Repeat interval for critical alerts | 10 min |
| `input_number.notification_battery_threshold_pct` | Low battery alert threshold | 20 % |
| `input_number.notification_filter_interval_days` | Kitchen filter replacement interval | 120 days |
| `input_number.car_current_mileage` | Current car mileage | — |
| `input_number.car_next_service_km` | Mileage at next service | — |
| `input_datetime.kitchen_filters_replaced` | Date filters were last replaced | — |

---

## Aggregation Sensors

Calculated automatically. The snooze map is taken into account.

| Entity | Description |
|---|---|
| `sensor.notification_feed` | State = count of active, non-snoozed alerts. Attribute `active_json`: JSON array sorted by priority. |
| `sensor.notification_count_critical` | Count of active, non-snoozed critical alerts |
| `binary_sensor.notification_any_active` | `on` when `sensor.notification_feed` > 0 |
| `binary_sensor.notification_any_critical` | `on` when `sensor.notification_count_critical` > 0 |

---

## Included Notification Sources

### Maintenance

| Entity | Priority | Description | Dependency |
|---|---|---|---|
| `notification_hass_update_available` | info | HA Core update available | `update.home_assistant_core_update` |
| `notification_update_available` | info | Integration/add-on updates (excluding Core) | `update.*` |
| `notification_ha_repairs` | warning | HA Repairs entries present | `sensor.repairs` |
| `notification_replace_kitchen_filters` | warning | Kitchen filter overdue. Confirm button sets date to today. | `sensor.kitchen_filters_days_remaining`, `input_datetime.kitchen_filters_replaced` |
| `notification_car_service_due` | warning | Mileage has reached service threshold | `input_number.car_current_mileage`, `input_number.car_next_service_km` |
| `notification_critical_sensors_unavailable` | warning | Safety sensors (smoke, water, door) are unavailable | whitelist of entity IDs |

### Security

| Entity | Priority | Description | Dependency |
|---|---|---|---|
| `notification_smoke_co_alarm` | critical | Smoke or CO alarm triggered | `binary_sensor.smoke_detector_combined` |
| `notification_water_leak` | critical | Water leak detected | `binary_sensor.water_leak_combined` |
| `notification_front_door_open` | warning | Front door is open | `binary_sensor.wohnungstuer` |

### Environment

| Entity | Priority | Description | Dependency |
|---|---|---|---|
| `notification_humidity` | warning | Indoor humidity outside normal range | `sensor.humidity_state` |
| `notification_co2` | warning | CO2 level high (≥ 1000 ppm) | `sensor.co2_state` |
| `notification_todays_precipitation` | info | Precipitation forecast but no current rain | `sensor.koti_precipitation` |
| `notification_raining` | info | Rain currently measured | `sensor.netatmo_rain_current` |

### Appliance

| Entity | Priority | Description | Dependency |
|---|---|---|---|
| `notification_vacuuming` | info | Robot vacuum active (cleaning / returning / error) | `vacuum.k11` |

### Devices

| Entity | Priority | Description | Dependency |
|---|---|---|---|
| `notification_low_battery` | warning | At least one device below threshold (default 20%) | `sensor.low_battery_devices` |

---

## Dependency Sensors

Managed internally. Do not define these separately in your HA config.

| Sensor | Description |
|---|---|
| `sensor.kitchen_filters_days_remaining` | Days until next kitchen filter replacement. Interval from `input_number.notification_filter_interval_days`. |
| `sensor.low_battery_devices` | Count of devices at or below `input_number.notification_battery_threshold_pct`. Attribute `devices`: list of affected entity IDs. |
| `sensor.humidity_state` | `Low` / `High` / `Normal` based on indoor humidity and outdoor temperature |
| `sensor.co2_state` | `High` when any monitored room ≥ 1000 ppm CO2, otherwise `Low`. Attribute `reporting_entity`: first offending sensor. |
| `sensor.air_quality` | Combined status string from `sensor.co2_state` and `sensor.humidity_state`. Useful for dashboards. |

---

## Automations

| Automation | Description |
|---|---|
| `notification_router_on_activate` | `off→on` transitions — startup guard + snooze check, routes to Mobile/Email/Persistent by priority |
| `notification_router_auto_resolve` | `on→off` — dismisses the associated persistent notification |
| `notification_delivery_critical_repeat` | Every minute: re-sends active critical alerts when repeat interval has elapsed, respects snooze |
| `notification_snooze_set` | `notification_snooze` event → merges entry into `var.notification_snooze_map` |
| `notification_cleanup_maps` | Daily at 03:00 — removes expired snooze entries and orphaned repeat slugs |
| `notification_snooze_catchup` | Every minute: re-delivers alerts that were active during a snooze and whose snooze just expired (within last 60s) |
