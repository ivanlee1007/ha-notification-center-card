# Notification Framework für Home Assistant — Handbuch

---

## Konzept

Das Framework stellt ein einheitliches, erweiterbares Benachrichtigungssystem für Home Assistant bereit.
Es abstrahiert Push-Benachrichtigungen, E-Mails, Persistent Notifications und Dashboard-Darstellung
hinter einer einzigen einfachen Schnittstelle:

**Eine neue Meldung = Ein neuer `binary_sensor.notification_*` mit Attributen.**

Das System übernimmt automatisch:
- Routing nach Priority (Mobile Push, E-Mail, Persistent Notification)
- Wiederholung kritischer Meldungen in konfigurierbarem Intervall
- Snooze pro Meldung direkt aus dem Dashboard
- Bestätigungsaktionen pro Meldung (z.B. „Filter erneuert")
- Dashboard-Darstellung wahlweise als Chip + Dropdown, schwebender Banner oder Liste

---

## Architektur

```
binary_sensor.notification_*   ←  Quellen (eigene Logik, beliebig erweiterbar)
         │
         ▼
sensor.notification_feed        ←  sammelt alle aktiven, nicht-gesnoozeten Quellen
         │
         ├──▶  notif_chip_2.yaml        →  Dashboard Chip + Floating-Dropdown
         ├──▶  notif_banner.yaml        →  schwebender Critical Banner
         ├──▶  notif_list               →  vollständige Meldungsliste (Template)
         │
         └──▶  notif_automations.yaml
                    ├── Router           →  erkennt on/off, prüft Snooze & Startup
                    ├── Delivery Mobile  →  notify.notify
                    ├── Delivery E-Mail  →  notify.gmail_smtp
                    ├── Delivery Persist →  persistent_notification
                    ├── Critical Repeat  →  wiederholt alle N Minuten
                    ├── Snooze Set       →  aktualisiert Snooze-Map
                    ├── Cleanup Maps     →  tägliche Bereinigung veralteter Einträge
                    └── Snooze Catch-up  →  erneute Zustellung nach Snooze-Ablauf
```

---

## Dateistruktur

```
config/
├── packages/
│   └── notifications.yaml                  ← Helpers & Einstiegspunkt
│
├── notifications/
│   ├── templates/
│   │   ├── notif_sources.yaml              ← ✏️ primärer Bearbeitungspunkt
│   │   └── notif_aggregation.yaml          ← nicht bearbeiten
│   └── notif_automations.yaml              ← nicht bearbeiten (außer Service-Namen)
│
└── lovelace/notifications/
    ├── notif_shared.yaml                   ← Gemeinsames Basis-Template
    ├── notif_chip_2.yaml                   ← Chip + Floating-Dropdown
    ├── notif_banner.yaml                   ← Schwebender Critical Banner
    ├── notif_pills.yaml                    ← Pill-Leiste
    └── notif_list.yaml                     ← Listen-Karten-Template
```

### Aufbau von `notifications.yaml`

Die Package-Datei ist in zwei klar gekennzeichnete Bereiche aufgeteilt:

- **FRAMEWORK INTERNALS** (`██`-Header) — `var.*`-Maps und `input_boolean`. Nicht bearbeiten.
- **USER SETTINGS** (`▓▓`-Header) — Schwellwerte und quellspezifische Helpers. Sicher anzupassen.

User Settings Unterabschnitte:
- *Framework thresholds* — Wiederholungsintervall, Batterie-Schwellwert
- *Source-specific values* — Helpers die zu konkreten Notifications gehören
- *Date helpers* — `input_datetime`-Einträge

---

## Eine neue Meldung hinzufügen

Neuen Block in `notif_sources.yaml` unter Abschnitt A einfügen:

```yaml
- name: notification_<slug>
  unique_id: notification_<slug>
  state: >
    {{ is_state('binary_sensor.my_entity', 'on') }}
  attributes:
    priority: warning
    category: general
    icon: mdi:alert
    icon_color: "var(--warning-color)"
    text_summary: "Kurzer Titel"
    text_description: "Optionaler Detailtext"
    tap_action: more-info
    tap_action_entity: binary_sensor.my_entity
```

Nach einem HA-Neustart wird die Meldung automatisch vom Feed-Sensor erkannt —
keine weitere Konfiguration notwendig.

Abschnitt C am Ende von `notif_sources.yaml` enthält auskommentierte Beispiel-Blöcke
für häufige Anwendungsfälle (CO2, Lüftungsfilter, Staubsauger, Wasserleck,
Urlaubsmodus, Strompreis).

---

## Attribute

### Pflichtattribute

| Attribut | Typ | Beschreibung |
|----------|-----|--------------|
| `priority` | `critical` \| `warning` \| `info` | Steuert Routing und Darstellung |
| `text_summary` | string | Kurztitel — erscheint im Dropdown und in Push-Benachrichtigungen |

### Optionale Attribute

| Attribut | Typ | Beschreibung |
|----------|-----|--------------|
| `category` | string | Freie Kategorisierung (z.B. `maintenance`, `security`) |
| `icon` | `mdi:*` | Icon im Dropdown |
| `icon_color` | CSS-Variable oder Hex | Icon-Farbe |
| `text_description` | string | Detailtext im Dropdown und in E-Mails |
| `tap_action` | `more-info` \| `dialog` \| `navigate` \| `url` | Aktion bei Klick auf die Zeile |
| `tap_action_entity` | entity_id | Für `more-info` und `dialog` |
| `tap_action_navigation_path` | `/lovelace/…` | Für `navigate` |
| `tap_action_url_path` | `https://…` | Für `url` |
| `confirm_action` | `domain.service` | Service-Aufruf beim Klick auf den Bestätigen-Button |
| `confirm_label` | string | Beschriftung des Bestätigen-Buttons (Standard: „Done") |
| `confirm_service_data` | JSON-String | Service-Daten als JSON-String. `"TODAY"` wird zur Laufzeit durch das aktuelle Datum im Format `YYYY-MM-DD` ersetzt |

### Wichtige Regeln

- `state` muss explizit `false` zurückgeben wenn die abhängige Entity `unavailable` oder `unknown` ist.
- Immer sichere Standardwerte verwenden: `| int(0)`, `| float(0.0)`.
- `state_attr(...)` kann `None` zurückgeben — vor der Verwendung von `| list` prüfen.
- Bei numerischen Sensorwerten immer validieren: `not in ['unknown','unavailable','']` **und** `| int(-1) >= 0` — verhindert Phantomwerte beim Start.
- Der Snooze-Slug wird aus dem Entity-Namen abgeleitet: `binary_sensor.notification_front_door_open` → Slug `front_door_open`.

---

## Priority Routing

| Priority | Mobile Push | Persistent | E-Mail | Critical Repeat |
|----------|:-----------:|:----------:|:------:|:---------------:|
| critical | ✅ | ✅ | ✅ | ✅ |
| warning  | ✅ | ❌ | ✅ | ❌ |
| info     | ❌ | ✅ | ❌ | ❌ |

- **Mobile:** `notify.notify` (durch eigenen Service ersetzen)
- **E-Mail:** `notify.gmail_smtp` (durch eigenen Service ersetzen)
- **Critical Repeat:** Intervall über `input_number.notification_critical_repeat_interval_min` (Standard: 10 min)

---

## Router — Bedingungen

Der Router feuert nur wenn alle vier Bedingungen erfüllt sind:

1. Entity entspricht `binary_sensor.notification_*` (Aggregations-Sensoren ausgeschlossen)
2. Übergang war `off → on`
3. Vorheriger Zustand war **nicht** `unknown` / `unavailable` / leer — verhindert Fehlauslösungen beim HA-Start
4. Notification ist nicht aktuell gesnoozet

---

## Dashboard — Drei unabhängige UI-Komponenten

### Chip + Dropdown (`notif_chip_2.yaml`)

Immer sichtbar im zugewiesenen Grid-Bereich.

| Zustand | Icon | Badge |
|---------|------|-------|
| Keine aktiven Meldungen | `mdi:bell-outline` | — |
| Aktive Meldungen | `mdi:bell-badge` | Anzahl |
| Dropdown offen | `mdi:bell-ring` | Anzahl |

Klick öffnet das Dropdown mit allen aktiven Meldungen sortiert nach Priority.
Jede Zeile hat einen Priority-Farbbalken, Icon, Zusammenfassung, optionalen Detailtext,
Snooze-Button (warning/info) oder Bestätigen-Button (wenn `confirm_action` gesetzt).

### Critical Banner (`notif_banner.yaml`)

Schwebt `position: fixed` über dem Dashboard via `card-mod` (`top: 60px`, zentriert).
Wird nur dargestellt wenn kritische Meldungen aktiv sind.

### Listen-Karte (`notif_list.yaml`)

Button-card-Template. Scrollbare Liste aller aktiven Meldungen mit Priority-Farbbalkern,
Snooze-Panel und Bestätigen-Button.

```yaml
type: custom:button-card
entity: sensor.notification_feed
template: notif_list
view_layout:
  grid-area: boxX
```

### Beschriftungen lokalisieren

`notif_chip_2.yaml` und `notif_list.yaml` erben gemeinsame Beschriftungen und
Basis-Defaults aus `notif_shared.yaml`. Varianten-spezifische Labels bleiben in
den jeweiligen Template-Dateien.

Die gemeinsamen Beschriftungen liegen im `variables:`-Block, z.B.:

```yaml
variables:
  label_snooze: "Snooze"
  label_confirm: "Done"
  label_h1: "1h"
  label_h4: "4h"
  label_tomorrow: "Tomorrow"
  label_day_after: "Day after"
```

Diese gemeinsamen `label_*`-Werte in `notif_shared.yaml` anpassen, um Chip und
Liste gemeinsam zu lokalisieren. `notif_pills.yaml` und `notif_banner.yaml`
werden separat lokalisiert.

---

## Snooze

Klick auf den Snooze-Button im Dropdown oder in der Listen-Karte öffnet den Zeitwähler:

| Option | Zeit |
|--------|------|
| 1h | Jetzt + 1 Stunde |
| 4h | Jetzt + 4 Stunden |
| Tomorrow | Nächster Tag um 08:00 |
| Day after | Übernächster Tag um 08:00 |

Timestamps werden in **Lokalzeit** gespeichert (nicht UTC). Alternativ das Event manuell feuern:

```yaml
event: notification_snooze
event_data:
  slug: front_door_open
  until: "2026-03-10T08:00:00"
```

Gesnoozete Meldungen werden aus Badge, Dropdown, Banner, Listen-Karte und Push/E-Mail-Zustellung ausgeschlossen.

**Snooze Catch-up:** Wenn eine Meldung während eines Snoozed-Zeitraums aktiv wird, stellt die
Automation `notification_snooze_catchup` sie sofort nach Ablauf des Snoozed-Zeitraums erneut zu
(minütliche Prüfung). Dadurch geht keine Benachrichtigung unbemerkt verloren.

---

## Bestätigungsaktion

```yaml
confirm_action: input_datetime.set_datetime
confirm_label: "Filter erneuert"
confirm_service_data: '{"entity_id":"input_datetime.kitchen_filters_replaced","date":"TODAY"}'
```

`TODAY` wird zur Laufzeit durch das aktuelle Datum im Format `YYYY-MM-DD` ersetzt.

Button-Logik nach Priority:

| Bedingung | Snooze-Button | Bestätigen-Button |
|---|---|---|
| `critical` ohne `confirm_action` | — | — |
| `critical` mit `confirm_action` | — | ✅ |
| `warning`/`info` ohne `confirm_action` | ✅ | — |
| `warning`/`info` mit `confirm_action` | — | ✅ |

---

## JSON-Speicher

Das Framework speichert zwei JSON-Maps in `var`-Entities — in der HA-SQLite-Datenbank
persistiert und überlebt Neustarts.

### `var.notification_snooze_map`
```json
{"water_leak": "2026-03-10T08:00:00", "low_battery": "2026-03-11T08:00:00"}
```
Geschrieben von `notification_snooze_set`. Gelesen von Feed-Sensor und Router.

### `var.notification_repeat_map`
```json
{"smoke_co_alarm": "2026-03-09T16:42:00"}
```
Geschrieben von der Critical-Repeat-Automation nach jeder Zustellung.
Verwaiste Einträge werden täglich von `notification_cleanup_maps` entfernt.

---

## Helpers

### Framework-Interna — nicht bearbeiten

| Entity | Zweck | Standard |
|---|---|---|
| `var.notification_snooze_map` | JSON-Map: Slug → Snooze-Timestamp | `{}` |
| `var.notification_repeat_map` | JSON-Map: Slug → letzter Repeat-Timestamp | `{}` |
| `input_boolean.notification_dropdown_open` | Steuert Dropdown-Zustand | `false` |

### Benutzereinstellungen — sicher anpassbar

| Entity | Zweck | Standard |
|---|---|---|
| `input_number.notification_critical_repeat_interval_min` | Wiederholungsintervall für kritische Meldungen | 10 min |
| `input_number.notification_battery_threshold_pct` | Schwellwert für niedrige Batterie | 20 % |
| `input_number.notification_filter_interval_days` | Küchenfilter-Austauschintervall | 120 Tage |
| `input_number.car_current_mileage` | Aktueller Kilometerstand | — |
| `input_number.car_next_service_km` | Kilometerstand beim nächsten Service | — |
| `input_datetime.kitchen_filters_replaced` | Datum des letzten Filterwechsels | — |

---

## Aggregations-Sensoren

Werden automatisch berechnet. Die Snooze-Map wird berücksichtigt.

| Entity | Beschreibung |
|---|---|
| `sensor.notification_feed` | State = Anzahl aktiver, nicht-gesnoozeter Meldungen. Attribut `active_json`: JSON-Array sortiert nach Priority. |
| `sensor.notification_count_critical` | Anzahl aktiver, nicht-gesnoozeter kritischer Meldungen |
| `binary_sensor.notification_any_active` | `on` wenn `sensor.notification_feed` > 0 |
| `binary_sensor.notification_any_critical` | `on` wenn `sensor.notification_count_critical` > 0 |

---

## Enthaltene Notification-Quellen

### Wartung

| Entity | Priority | Beschreibung | Abhängigkeit |
|---|---|---|---|
| `notification_hass_update_available` | info | HA Core-Update verfügbar | `update.home_assistant_core_update` |
| `notification_update_available` | info | Integration-/Add-on-Updates (außer Core) | `update.*` |
| `notification_ha_repairs` | warning | HA Repairs-Einträge vorhanden | `sensor.repairs` |
| `notification_replace_kitchen_filters` | warning | Küchenfilter-Wechsel überfällig. Bestätigen-Button setzt Datum auf heute. | `sensor.kitchen_filters_days_remaining`, `input_datetime.kitchen_filters_replaced` |
| `notification_car_service_due` | warning | Kilometerstand hat Service-Schwellwert erreicht | `input_number.car_current_mileage`, `input_number.car_next_service_km` |
| `notification_critical_sensors_unavailable` | warning | Sicherheitssensoren (Rauch, Wasser, Tür) nicht verfügbar | Whitelist von Entity-IDs |

### Sicherheit

| Entity | Priority | Beschreibung | Abhängigkeit |
|---|---|---|---|
| `notification_smoke_co_alarm` | critical | Rauch- oder CO-Alarm ausgelöst | `binary_sensor.smoke_detector_combined` |
| `notification_water_leak` | critical | Wasserleck erkannt | `binary_sensor.water_leak_combined` |
| `notification_front_door_open` | warning | Haustür ist offen | `binary_sensor.wohnungstuer` |

### Umgebung

| Entity | Priority | Beschreibung | Abhängigkeit |
|---|---|---|---|
| `notification_humidity` | warning | Innenraumfeuchtigkeit außerhalb des Normalbereichs | `sensor.humidity_state` |
| `notification_co2` | warning | CO2-Gehalt erhöht (≥ 1000 ppm) | `sensor.co2_state` |
| `notification_todays_precipitation` | info | Niederschlag vorhergesagt, aber kein aktueller Regen | `sensor.koti_precipitation` |
| `notification_raining` | info | Aktuell gemessener Regen | `sensor.netatmo_rain_current` |

### Geräte

| Entity | Priority | Beschreibung | Abhängigkeit |
|---|---|---|---|
| `notification_vacuuming` | info | Roboter-Staubsauger aktiv (saugt / kehrt zurück / Fehler) | `vacuum.k11` |
| `notification_low_battery` | warning | Mindestens ein Gerät unter Schwellwert (Standard 20 %) | `sensor.low_battery_devices` |

---

## Abhängigkeits-Sensoren

Intern vom Framework verwaltet. Nicht separat in der HA-Konfiguration definieren.

| Sensor | Beschreibung |
|---|---|
| `sensor.kitchen_filters_days_remaining` | Verbleibende Tage bis zum nächsten Küchenfilter-Wechsel. Intervall aus `input_number.notification_filter_interval_days`. |
| `sensor.low_battery_devices` | Anzahl der Geräte bei oder unter `input_number.notification_battery_threshold_pct`. Attribut `devices`: Liste der betroffenen Entity-IDs. |
| `sensor.humidity_state` | `Low` / `High` / `Normal` basierend auf Innenraumfeuchtigkeit und Außentemperatur |
| `sensor.co2_state` | `High` wenn ein überwachter Raum ≥ 1000 ppm CO2, sonst `Low`. Attribut `reporting_entity`: erster betroffener Sensor. |
| `sensor.air_quality` | Kombinierter Statustext aus `sensor.co2_state` und `sensor.humidity_state`. Nützlich für Dashboards. |

---

## Automationen

| Automation | Beschreibung |
|---|---|
| `notification_router_on_activate` | `off→on`-Übergänge — Startup-Guard + Snooze-Prüfung, leitet an Mobile/E-Mail/Persistent weiter |
| `notification_router_auto_resolve` | `on→off` — löscht die zugehörige Persistent Notification |
| `notification_delivery_critical_repeat` | Minütlich: sendet aktive kritische Meldungen erneut wenn Intervall abgelaufen, respektiert Snooze |
| `notification_snooze_set` | `notification_snooze`-Event → schreibt Eintrag in `var.notification_snooze_map` |
| `notification_cleanup_maps` | Täglich um 03:00 — entfernt abgelaufene Snooze-Einträge und verwaiste Repeat-Slugs |
| `notification_snooze_catchup` | Minütlich: stellt Meldungen erneut zu die während des Snoozed-Zeitraums aktiv waren und deren Snooze gerade abgelaufen ist |
